package bus;

public enum EnumCurrency {
	USD,
	JPY,
	EUR,
	CAD,
	BRL,
	Undefined
}
