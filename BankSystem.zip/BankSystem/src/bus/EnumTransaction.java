package bus;

public enum EnumTransaction {
	Withdraw,
	Deposit,
	CheckBalance,
	Undefined
}
