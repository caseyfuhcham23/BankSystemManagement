package bus;

public enum EnumAccount {
	CheckingAccount,
	SavingsAccount,
	CurrencyAccount,
	LineOfCreditAccount,
	CreditAccount,
	Undefined
}
